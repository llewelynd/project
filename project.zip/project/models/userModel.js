const users = [
    { id: 1, username: 'testuser', password: 'password123', email: 'test@example.com' }
  ];
  
  module.exports = users;
  