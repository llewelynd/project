const users = require('../models/userModel');

// Mock authentication middleware
const authenticate = (req, res, next) => {
  const token = req.headers['authorization'];

  if (token !== 'mock-token') {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  // Assuming user with id 1 is logged in
  req.user = users[0];
  next();
};

module.exports = { authenticate };
