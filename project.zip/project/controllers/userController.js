const users = require('../models/userModel');

// Register a new user
const register = (req, res) => {
  const { username, password, email } = req.body;
  
  if (users.find(user => user.username === username)) {
    return res.status(400).json({ message: 'Username already exists' });
  }
  
  const newUser = {
    id: users.length + 1,
    username,
    password, // In real apps, passwords should be hashed
    email
  };
  
  users.push(newUser);
  res.status(201).json({ message: 'User registered successfully' });
};

// User login
const login = (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  
  res.json({ message: 'Login successful', token: 'mock-token' }); // Replace with JWT in real implementation
};

// Get user profile
const getProfile = (req, res) => {
  const user = req.user; // Extracted from auth middleware
  res.json(user);
};

module.exports = { register, login, getProfile };
